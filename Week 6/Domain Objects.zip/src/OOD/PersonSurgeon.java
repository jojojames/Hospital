package OOD;

public class PersonSurgeon {
    public Surgeon surgeon;
    public Person person;

    /**
     *
     */
    public PersonSurgeon() {
    }
}
