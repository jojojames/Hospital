package OOD;

public class Cash {
    public BillingStatement billingStatement;

    /**
     *
     */
    public Cash() {
    }
}
