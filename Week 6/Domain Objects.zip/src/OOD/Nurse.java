package OOD;

import java.util.Vector;

public class Nurse {
    public Surgeon surgeon;
    public Department department;
    public Vector patientNurse = new Vector();
    public Skills skills;
    public Vector surgeryNurse = new Vector();
    public Vector personNurse = new Vector();
    public Doctor doctor;
    public Ward ward;

    /**
     *
     */
    public Nurse() {
    }
}
