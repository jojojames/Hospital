package OOD;

public class PersonDoctor {
    public Person person;
    public Doctor doctor;

    /**
     *
     */
    public PersonDoctor() {
    }
}
