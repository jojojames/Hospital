package OOD;

public class SurgeryNurse {
    public Surgery surgery;
    public Nurse nurse;

    /**
     *
     */
    public SurgeryNurse() {
    }
}
