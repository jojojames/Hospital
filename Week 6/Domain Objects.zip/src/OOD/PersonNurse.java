package OOD;

public class PersonNurse {
    public Person person;
    public Nurse nurse;

    /**
     *
      */
    public PersonNurse(){
        
    }
}
