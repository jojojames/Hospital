package OOD;

public class DoctorExaminationRoom {
    public ExaminationRoom examinationRoom;
    public Doctor doctor;

    /**
     *
     */
    public DoctorExaminationRoom() {
    }
}
