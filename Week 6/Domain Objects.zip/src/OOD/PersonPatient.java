package OOD;

public class PersonPatient {
    public Patient patient;
    public Person person;

    /**
     *
      */
    public PersonPatient(){
        
    }
}
