package OOD;

public class PatientSurgeon {
    public Patient patient;
    public Surgeon surgeon;

    /**
     *
     */
    public PatientSurgeon() {
    }
}
