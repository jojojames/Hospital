package OOD;

public class PatientNurse {
    public Patient patient;
    public Nurse nurse;

    /**
     *
     */
    public PatientNurse() {
    }
}
