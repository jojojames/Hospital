package OOD;

public class SurgeonSurgery {
    public Surgery surgery;
    public Surgeon surgeon;

    /**
     *
     */
    public SurgeonSurgery() {
    }
}
