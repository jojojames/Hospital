package OOD;

public class AssistantSurgery {
    public Surgery surgery;
    public Assistant assistant;

    /**
     *
     */
    public AssistantSurgery() {
    }
}
