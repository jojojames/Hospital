package OOD;

public class Bed {
    private int BedID;

    /**
     *
     * @param bedID
     */
    public Bed(int bedID) {
        this.BedID = bedID;
    }
}
