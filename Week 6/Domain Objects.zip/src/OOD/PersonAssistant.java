package OOD;

public class PersonAssistant {
    public Assistant assistant;
    public Person person;

    /**
     *
      */
    public PersonAssistant(){
        
    }
}
