package OOD;

import java.util.Vector;

public class Assistant {
    public Vector personAssistant = new Vector();
    public Skills skills;
    public Vector doctorAssistant = new Vector();
    public Vector surgeryAssistant = new Vector();
    public Surgeon surgeon;

    /**
     *
     */
    public Assistant() {
    }
}
