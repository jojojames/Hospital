package OOD;

public class PersonHead {
    public Person person;
    public Head head;

    /**
     *
     */
    public PersonHead() {
    }
}
