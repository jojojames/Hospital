package OOD;

public class DoctorAssistant {
    public Assistant assistant;
    public Doctor doctor;

    /**
     *
     */
    public DoctorAssistant() {
    }
}
